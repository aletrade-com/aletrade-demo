function toggleAssistant() {
  const chat = document.getElementById('chat');
  chat.style.display = chat.style.display === 'none' ? 'block' : 'none';
}